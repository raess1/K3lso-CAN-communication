#define VERSION_MAJOR		1
#define VERSION_MINOR		9
#define VERSION_PATCH		0
#define VERSION_BUILD		3

#define FILEVER 1,9,0,3
#define STRFILEVER "1.9.0.3"
#define STRPRODUCTVER "1.9"
#define COPYRIGHT "Copyright © 2018 PEAK-System Technik GmbH"
